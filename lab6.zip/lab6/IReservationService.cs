using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Text.Json.Serialization;

public class IReservationService
{

    public void createReservation(Reservation reservation)
    {
        // Create reservation
    }

    public void cancelReservation(string reservationId)
    {
        // Cancel reservation
    }

}
