using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Text.Json.Serialization;

public class ILogger
{
    public void Log(string message)
    {
        throw new NotImplementedException();
    }
}
